# Installation Guide - React Code Assistant

## Quick Installation

1. **Download the Extension**
   - The extension file `react-code-assistant-0.0.1.vsix` is now ready in this directory

2. **Install in VS Code**
   - Open VS Code
   - Press `Ctrl+Shift+X` to open Extensions
   - Click the three dots (...) menu at the top of the Extensions panel
   - Select "Install from VSIX..."
   - Choose the `react-code-assistant-0.0.1.vsix` file
   - Click "Install"
   - Reload VS Code when prompted

3. **Verify Installation**
   - The extension should appear in your Extensions list
   - Right-click in the file explorer or editor to see the new context menu options

## Features Available After Installation

### Right-Click Context Menus

#### File Explorer
- Right-click on any folder → "Create React App"
- Right-click on JS/JSX/TS/TSX files → Multiple generation options

#### Editor
- Right-click in JS/TS/React files → Component, Hook, Service generation

### Command Palette
- Press `Ctrl+Shift+P`
- Type "React Code Assistant" to see all available commands

## Testing the Extension

1. **Create a React App**
   - Right-click in file explorer
   - Select "Create React App"
   - Enter app name (e.g., "test-app")
   - Wait for creation to complete

2. **Generate Components**
   - Right-click on any JS/TS file
   - Select "Generate React Component"
   - Enter component name
   - Choose template type

## Troubleshooting

- If context menus don't appear, reload VS Code
- Check Extensions panel to ensure the extension is enabled
- Look for any error messages in the Output panel

## Support

For issues or questions, check the main README.md file or create an issue in the repository.
