// Demo file to showcase React Code Assistant extension
// Right-click in this file to see the context menu options

import React from 'react';

// This is a demo component to show the extension's capabilities
function DemoComponent() {
  return (
    <div className="demo">
      <h1>React Code Assistant Demo</h1>
      <p>Right-click in this file to see the extension options:</p>
      <ul>
        <li>Generate React Component</li>
        <li>Generate Custom Hook</li>
        <li>Generate Service/API</li>
        <li>Generate Test File</li>
      </ul>
    </div>
  );
}

export default DemoComponent;
