# React Code Assistant - VS Code Extension

A powerful VS Code extension that provides React app creation and code generation features with right-click context menus, similar to the watsonx Code Assistant for Z but focused on React development.

## Features

### 🚀 Create React App
- Generate a complete React application with a single click
- Includes all necessary files (package.json, src files, public files)
- Automatically installs dependencies
- Opens the new app in a new VS Code window

### 🧩 Generate React Components
- Create functional, class-based, or TypeScript components
- Automatically generates CSS files
- Configurable component templates
- Right-click context menu integration

### 🪝 Generate Custom Hooks
- Create reusable custom hooks
- Follows React hooks naming conventions
- Includes basic useState and useEffect structure

### 🔧 Generate Services/APIs
- Create service classes for API calls
- Includes CRUD operations (GET, POST, PUT, DELETE)
- Error handling and fetch API integration
- Environment variable support

### 🧪 Generate Test Files
- Create Jest test files for components
- Includes React Testing Library setup
- Basic test structure and examples

## Installation

### Method 1: Install from VSIX (Recommended)

1. Download the latest `.vsix` file from the releases
2. In VS Code, go to `Extensions` (Ctrl+Shift+X)
3. Click the three dots (...) menu and select "Install from VSIX..."
4. Choose the downloaded `.vsix` file
5. Reload VS Code when prompted

### Method 2: Build from Source

1. Clone this repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Compile the extension:
   ```bash
   npm run compile
   ```
4. Press F5 in VS Code to run the extension in a new Extension Development Host window
5. To package the extension:
   ```bash
   npm install -g vsce
   vsce package
   ```

## Usage

### Right-Click Context Menus

The extension adds context menu options in two places:

#### File Explorer Context Menu
Right-click on any file or folder in the explorer to see:
- **Create React App** - Create a new React application
- **Generate React Component** - Generate a new component (for JS/JSX/TS/TSX files)
- **Generate Custom Hook** - Generate a new custom hook (for JS/JSX/TS/TSX files)
- **Generate Service/API** - Generate a new service class (for JS/JSX/TS/TSX files)
- **Generate Test File** - Generate a test file (for JS/JSX/TS/TSX files)

#### Editor Context Menu
Right-click in the editor (when working with JavaScript/TypeScript/React files) to see:
- **Generate React Component** - Generate a new component
- **Generate Custom Hook** - Generate a new custom hook
- **Generate Service/API** - Generate a new service class
- **Generate Test File** - Generate a test file

### Command Palette

You can also access all features via the Command Palette (Ctrl+Shift+P):
- `React Code Assistant: Create React App`
- `React Code Assistant: Generate React Component`
- `React Code Assistant: Generate Custom Hook`
- `React Code Assistant: Generate Service/API`
- `React Code Assistant: Generate Test File`

## Configuration

The extension provides several configuration options. Go to VS Code Settings (Ctrl+,) and search for "React Code Assistant":

### Default Template
Choose the default component template:
- `functional` - Functional components with hooks
- `class` - Class-based components
- `typescript` - TypeScript components with interfaces

### Create Tests
Automatically create test files when generating components (default: true)

## Examples

### Creating a React App
1. Right-click in the file explorer
2. Select "Create React App"
3. Enter your app name (e.g., "my-awesome-app")
4. Wait for the app to be created and dependencies to install
5. The new app will open in a new VS Code window

### Generating a Component
1. Right-click on a JavaScript/TypeScript file
2. Select "Generate React Component"
3. Enter the component name (e.g., "UserProfile")
4. Choose your preferred template
5. The component file will be created and opened

### Generating a Custom Hook
1. Right-click in the editor
2. Select "Generate Custom Hook"
3. Enter the hook name (e.g., "Counter")
4. The hook file `useCounter.js` will be created

## File Structure

When you create a React app, the extension generates:

```
my-react-app/
├── package.json
├── public/
│   └── index.html
├── src/
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── index.css
└── README.md
```

## Requirements

- VS Code 1.60.0 or higher
- Node.js (for dependency installation)
- npm (for dependency installation)

## Troubleshooting

### Dependencies Installation Fails
If automatic dependency installation fails:
1. Open a terminal in the app directory
2. Run `npm install` manually
3. The extension will show a warning message with instructions

### Extension Not Working
1. Check that the extension is enabled
2. Reload VS Code (Ctrl+Shift+P → "Developer: Reload Window")
3. Check the Output panel for any error messages

### Right-Click Menu Not Showing
1. Ensure you're right-clicking on the correct file types
2. Check that the extension is properly installed
3. Try reloading VS Code

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This extension is licensed under the MIT License.

## Support

If you encounter any issues or have feature requests:
1. Check the existing issues on GitHub
2. Create a new issue with detailed information
3. Include your VS Code version and OS information

## Changelog

### Version 0.0.1
- Initial release
- Create React App functionality
- Component generation (functional, class, TypeScript)
- Custom hook generation
- Service/API generation
- Test file generation
- Right-click context menu integration
- Configuration options
