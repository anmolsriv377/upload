import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

export function activate(context: vscode.ExtensionContext) {
    console.log('React Code Assistant extension is now active!');
    
    // Show activation message
    vscode.window.showInformationMessage('React Code Assistant is now active! Right-click to see options.');

    try {
        // Register commands
        let createReactApp = vscode.commands.registerCommand('react-code-assistant.createReactApp', async () => {
            console.log('Create React App command triggered');
            try {
                await createReactAppCommand();
            } catch (error) {
                console.error('Error in createReactApp command:', error);
                vscode.window.showErrorMessage(`Failed to create React app: ${error}`);
            }
        });

        let generateComponent = vscode.commands.registerCommand('react-code-assistant.generateComponent', async () => {
            console.log('Generate Component command triggered');
            try {
                await generateComponentCommand();
            } catch (error) {
                console.error('Error in generateComponent command:', error);
                vscode.window.showErrorMessage(`Failed to generate component: ${error}`);
            }
        });

        let generateHook = vscode.commands.registerCommand('react-code-assistant.generateHook', async () => {
            console.log('Generate Hook command triggered');
            try {
                await generateHookCommand();
            } catch (error) {
                console.error('Error in generateHook command:', error);
                vscode.window.showErrorMessage(`Failed to generate hook: ${error}`);
            }
        });

        let generateService = vscode.commands.registerCommand('react-code-assistant.generateService', async () => {
            console.log('Generate Service command triggered');
            try {
                await generateServiceCommand();
            } catch (error) {
                console.error('Error in generateService command:', error);
                vscode.window.showErrorMessage(`Failed to generate service: ${error}`);
            }
        });

        let generateTest = vscode.commands.registerCommand('react-code-assistant.generateTest', async () => {
            console.log('Generate Test command triggered');
            try {
                await generateTestCommand();
            } catch (error) {
                console.error('Error in generateTest command:', error);
                vscode.window.showErrorMessage(`Failed to generate test: ${error}`);
            }
        });

        context.subscriptions.push(createReactApp, generateComponent, generateHook, generateService, generateTest);
        
        console.log('All commands registered successfully');
    } catch (error) {
        console.error('Error during extension activation:', error);
        vscode.window.showErrorMessage(`Extension activation failed: ${error}`);
    }
}

async function createReactAppCommand() {
    console.log('createReactAppCommand started');
    try {
        // Get workspace folder
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        console.log('Workspace folder:', workspaceFolder);
        if (!workspaceFolder) {
            vscode.window.showErrorMessage('No workspace folder found. Please open a folder in VS Code.');
            return;
        }

        // Prompt for app name
        const appName = await vscode.window.showInputBox({
            prompt: 'Enter React app name',
            placeHolder: 'my-react-app',
            validateInput: (value) => {
                if (!value || value.trim() === '') {
                    return 'App name cannot be empty';
                }
                if (!/^[a-z0-9-]+$/.test(value)) {
                    return 'App name can only contain lowercase letters, numbers, and hyphens';
                }
                return null;
            }
        });

        if (!appName) {
            return;
        }

        const appPath = path.join(workspaceFolder.uri.fsPath, appName);

        // Check if directory already exists
        if (fs.existsSync(appPath)) {
            const overwrite = await vscode.window.showWarningMessage(
                `Directory "${appName}" already exists. Do you want to overwrite it?`,
                'Yes', 'No'
            );
            if (overwrite !== 'Yes') {
                return;
            }
            fs.rmSync(appPath, { recursive: true, force: true });
        }

        // Show progress
        await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: `Creating React app: ${appName}`,
            cancellable: false
        }, async (progress) => {
            progress.report({ increment: 0 });

            try {
                // Create app directory
                if (!fs.existsSync(appPath)) {
                    fs.mkdirSync(appPath, { recursive: true });
                }
                progress.report({ increment: 20 });

                // Create package.json
                const packageJson = {
                    name: appName,
                    version: "0.1.0",
                    private: true,
                    dependencies: {
                        "react": "^18.2.0",
                        "react-dom": "^18.2.0",
                        "react-scripts": "5.0.1"
                    },
                    scripts: {
                        "start": "react-scripts start",
                        "build": "react-scripts build",
                        "test": "react-scripts test",
                        "eject": "react-scripts eject"
                    },
                    "eslintConfig": {
                        "extends": [
                            "react-app",
                            "react-app/jest"
                        ]
                    },
                    "browserslist": {
                        "production": [
                            ">0.2%",
                            "not dead",
                            "not op_mini all"
                        ],
                        "development": [
                            "last 1 chrome version",
                            "last 1 firefox version",
                            "last 1 safari version"
                        ]
                    }
                };

                fs.writeFileSync(path.join(appPath, 'package.json'), JSON.stringify(packageJson, null, 2));
                progress.report({ increment: 30 });

                // Create public/index.html
                const publicDir = path.join(appPath, 'public');
                if (!fs.existsSync(publicDir)) {
                    fs.mkdirSync(publicDir, { recursive: true });
                }
                
                const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="icon" href="%PUBLIC_URL%/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Web site created using create-react-app" />
    <title>React App</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>`;

                fs.writeFileSync(path.join(publicDir, 'index.html'), indexHtml);
                progress.report({ increment: 40 });

                // Create src/App.js
                const srcDir = path.join(appPath, 'src');
                if (!fs.existsSync(srcDir)) {
                    fs.mkdirSync(srcDir, { recursive: true });
                }

                const appJs = `import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to ${appName}</h1>
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;`;

                fs.writeFileSync(path.join(srcDir, 'App.js'), appJs);
                progress.report({ increment: 50 });

                // Create src/index.js
                const indexJs = `import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`;

                fs.writeFileSync(path.join(srcDir, 'index.js'), indexJs);
                progress.report({ increment: 60 });

                // Create basic CSS files
                const appCss = `.App {
  text-align: center;
}

.App-header {
  background-color: #282c34;
  padding: 20px;
  color: white;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: calc(10px + 2vmin);
}

.App-link {
  color: #61dafb;
}`;

                fs.writeFileSync(path.join(srcDir, 'App.css'), appCss);
                progress.report({ increment: 70 });

                const indexCss = `body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}`;

                fs.writeFileSync(path.join(srcDir, 'index.css'), indexCss);
                progress.report({ increment: 80 });

                // Create README.md
                const readme = `# ${appName}

This project was created with React Code Assistant.

## Available Scripts

In the project directory, you can run:

### \`npm start\`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### \`npm test\`

Launches the test runner in the interactive watch mode.

### \`npm run build\`

Builds the app for production to the \`build\` folder.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).`;

                fs.writeFileSync(path.join(appPath, 'README.md'), readme);
                progress.report({ increment: 90 });

                progress.report({ increment: 100 });
            } catch (error) {
                throw error;
            }
        });

        // Open the new app in VS Code
        const uri = vscode.Uri.file(appPath);
        await vscode.commands.executeCommand('vscode.openFolder', uri);

        vscode.window.showInformationMessage(
            `React app "${appName}" created successfully! Opening in new window...`
        );

    } catch (error) {
        console.error('Error creating React app:', error);
        vscode.window.showErrorMessage(`Failed to create React app: ${error}`);
    }
}

async function generateComponentCommand() {
    try {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found.');
            return;
        }

        const componentName = await vscode.window.showInputBox({
            prompt: 'Enter component name',
            placeHolder: 'MyComponent',
            validateInput: (value) => {
                if (!value || value.trim() === '') {
                    return 'Component name cannot be empty';
                }
                if (!/^[A-Z][a-zA-Z0-9]*$/.test(value)) {
                    return 'Component name must start with a capital letter and contain only letters and numbers';
                }
                return null;
            }
        });

        if (!componentName) {
            return;
        }

        const config = vscode.workspace.getConfiguration('reactCodeAssistant');
        const templateType = config.get('defaultTemplate', 'functional') as string;

        let componentCode = '';
        let fileExtension = '.js';

        switch (templateType) {
            case 'typescript':
                fileExtension = '.tsx';
                componentCode = generateTypeScriptComponent(componentName);
                break;
            case 'class':
                componentCode = generateClassComponent(componentName);
                break;
            default:
                componentCode = generateFunctionalComponent(componentName);
        }

        // Get current file directory
        const currentFilePath = editor.document.uri.fsPath;
        const currentDir = path.dirname(currentFilePath);
        const componentPath = path.join(currentDir, `${componentName}${fileExtension}`);

        // Check if file already exists
        if (fs.existsSync(componentPath)) {
            const overwrite = await vscode.window.showWarningMessage(
                `File "${componentName}${fileExtension}" already exists. Do you want to overwrite it?`,
                'Yes', 'No'
            );
            if (overwrite !== 'Yes') {
                return;
            }
        }

        // Write component file
        fs.writeFileSync(componentPath, componentCode);

        // Open the new component file
        const uri = vscode.Uri.file(componentPath);
        const doc = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(doc);

        vscode.window.showInformationMessage(
            `Component "${componentName}" generated successfully!`
        );

    } catch (error) {
        console.error('Error generating component:', error);
        vscode.window.showErrorMessage(`Failed to generate component: ${error}`);
    }
}

function generateFunctionalComponent(name: string): string {
    return `import React from 'react';
import './${name}.css';

const ${name}: React.FC = () => {
  return (
    <div className="${name.toLowerCase()}">
      <h2>${name}</h2>
      <p>This is the ${name} component.</p>
    </div>
  );
};

export default ${name};`;
}

function generateClassComponent(name: string): string {
    return `import React, { Component } from 'react';
import './${name}.css';

class ${name} extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="${name.toLowerCase()}">
        <h2>${name}</h2>
        <p>This is the ${name} component.</p>
      </div>
    );
  }
}

export default ${name};`;
}

function generateTypeScriptComponent(name: string): string {
    return `import React from 'react';
import './${name}.css';

interface ${name}Props {
  // Add your props here
}

const ${name}: React.FC<${name}Props> = (props) => {
  return (
    <div className="${name.toLowerCase()}">
      <h2>${name}</h2>
      <p>This is the ${name} component.</p>
    </div>
  );
};

export default ${name};`;
}

async function generateHookCommand() {
    try {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found.');
            return;
        }

        const hookName = await vscode.window.showInputBox({
            prompt: 'Enter hook name (without "use" prefix)',
            placeHolder: 'Counter',
            validateInput: (value) => {
                if (!value || value.trim() === '') {
                    return 'Hook name cannot be empty';
                }
                if (!/^[A-Z][a-zA-Z0-9]*$/.test(value)) {
                    return 'Hook name must start with a capital letter and contain only letters and numbers';
                }
                return null;
            }
        });

        if (!hookName) {
            return;
        }

        const hookCode = `import { useState, useEffect } from 'react';

export const use${hookName} = () => {
  const [value, setValue] = useState(null);

  useEffect(() => {
    // Add your hook logic here
  }, []);

  return {
    value,
    setValue,
  };
};`;

        // Get current file directory
        const currentFilePath = editor.document.uri.fsPath;
        const currentDir = path.dirname(currentFilePath);
        const hookPath = path.join(currentDir, `use${hookName}.js`);

        // Check if file already exists
        if (fs.existsSync(hookPath)) {
            const overwrite = await vscode.window.showWarningMessage(
                `File "use${hookName}.js" already exists. Do you want to overwrite it?`,
                'Yes', 'No'
            );
            if (overwrite !== 'Yes') {
                return;
            }
        }

        // Write hook file
        fs.writeFileSync(hookPath, hookCode);

        // Open the new hook file
        const uri = vscode.Uri.file(hookPath);
        const doc = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(doc);

        vscode.window.showInformationMessage(
            `Hook "use${hookName}" generated successfully!`
        );

    } catch (error) {
        console.error('Error generating hook:', error);
        vscode.window.showErrorMessage(`Failed to generate hook: ${error}`);
    }
}

async function generateServiceCommand() {
    try {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found.');
            return;
        }

        const serviceName = await vscode.window.showInputBox({
            prompt: 'Enter service name',
            placeHolder: 'UserService',
            validateInput: (value) => {
                if (!value || value.trim() === '') {
                    return 'Service name cannot be empty';
                }
                if (!/^[A-Z][a-zA-Z0-9]*$/.test(value)) {
                    return 'Service name must start with a capital letter and contain only letters and numbers';
                }
                return null;
            }
        });

        if (!serviceName) {
            return;
        }

        const serviceCode = `class ${serviceName} {
  constructor() {
    this.baseURL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
  }

  async get(endpoint) {
    try {
      const response = await fetch(\`\${this.baseURL}\${endpoint}\`);
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }

  async post(endpoint, data) {
    try {
      const response = await fetch(\`\${this.baseURL}\${endpoint}\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error posting data:', error);
      throw error;
    }
  }

  async put(endpoint, data) {
    try {
      const response = await fetch(\`\${this.baseURL}\${endpoint}\`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error updating data:', error);
      throw error;
    }
  }

  async delete(endpoint) {
    try {
      const response = await fetch(\`\${this.baseURL}\${endpoint}\`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error deleting data:', error);
      throw error;
    }
  }
}

export default new ${serviceName}();`;

        // Get current file directory
        const currentFilePath = editor.document.uri.fsPath;
        const currentDir = path.dirname(currentFilePath);
        const servicePath = path.join(currentDir, `${serviceName}.js`);

        // Check if file already exists
        if (fs.existsSync(servicePath)) {
            const overwrite = await vscode.window.showWarningMessage(
                `File "${serviceName}.js" already exists. Do you want to overwrite it?`,
                'Yes', 'No'
            );
            if (overwrite !== 'Yes') {
                return;
            }
        }

        // Write service file
        fs.writeFileSync(servicePath, serviceCode);

        // Open the new service file
        const uri = vscode.Uri.file(servicePath);
        const doc = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(doc);

        vscode.window.showInformationMessage(
            `Service "${serviceName}" generated successfully!`
        );

    } catch (error) {
        console.error('Error generating service:', error);
        vscode.window.showErrorMessage(`Failed to generate service: ${error}`);
    }
}

async function generateTestCommand() {
    try {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found.');
            return;
        }

        const currentFilePath = editor.document.uri.fsPath;
        const fileName = path.basename(currentFilePath, path.extname(currentFilePath));
        const testPath = currentFilePath.replace(/\.[^/.]+$/, '.test.js');

        const testCode = `import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ${fileName} from './${fileName}';

describe('${fileName}', () => {
  test('renders without crashing', () => {
    render(<${fileName} />);
    expect(screen.getByText('${fileName}')).toBeInTheDocument();
  });

  test('displays correct content', () => {
    render(<${fileName} />);
    expect(screen.getByText(/This is the ${fileName} component/)).toBeInTheDocument();
  });
});`;

        // Check if file already exists
        if (fs.existsSync(testPath)) {
            const overwrite = await vscode.window.showWarningMessage(
                `Test file already exists. Do you want to overwrite it?`,
                'Yes', 'No'
            );
            if (overwrite !== 'Yes') {
                return;
            }
        }

        // Write test file
        fs.writeFileSync(testPath, testCode);

        // Open the new test file
        const uri = vscode.Uri.file(testPath);
        const doc = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(doc);

        vscode.window.showInformationMessage(
            `Test file generated successfully!`
        );

    } catch (error) {
        console.error('Error generating test:', error);
        vscode.window.showErrorMessage(`Failed to generate test: ${error}`);
    }
}

export function deactivate() {}
